#!/bin/sh

./pssac2 sample.sac -JX2i/2i -R0/10/0/2 -Ent-5 -V -M1 -B1/1 -P -K > pssac2_test_out.ps
pscoast -JM4i -R-130/-110/45/50 -K -O -Di -W1 -X3i -Slightblue -Gkhaki >> pssac2_test_out.ps
./pssac2 sample.sac -JM4i -R-130/-110/45/50 -B10 -Ent-5 -M1 -L5 -P -O  >> pssac2_test_out.ps
